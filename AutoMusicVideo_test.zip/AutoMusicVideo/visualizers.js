class Visualizer {
    constructor(canvas, audioAnalyzer) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.audioAnalyzer = audioAnalyzer;
        this.animationId = null;
        this.recording = false;
        this.recordingFrames = [];
        this.mediaRecorder = null;
        this.chunks = [];
        this.settings = {
            style: 'waveform',
            theme: 'dark',
            customization: {
                color1: '#ff0000',
                color2: '#0000ff',
                sensitivity: 1.0,
                complexity: 0.5
            }
        };
        
        // For 3D visualizations
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        
        // Set canvas size initially
        this.resizeCanvas();
        
        // Handle window resize
        window.addEventListener('resize', () => this.resizeCanvas());
    }
    
    resizeCanvas() {
        const container = this.canvas.parentElement;
        this.canvas.width = container.clientWidth;
        this.canvas.height = container.clientHeight;
        
        // If 3D context is active
        if (this.renderer) {
            this.renderer.setSize(this.canvas.width, this.canvas.height);
            this.camera.aspect = this.canvas.width / this.canvas.height;
            this.camera.updateProjectionMatrix();
        }
    }
    
    startVisualization() {
        this.stopVisualization();
        
        // Initialize 3D context if needed
        if (this.settings.style === '3d' && !this.scene) {
            this.init3D();
        }
        
        const animate = () => {
            this.animationId = requestAnimationFrame(animate);
            
            if (!this.audioAnalyzer.isPlaying) return;
            
            // Clear canvas
            if (this.settings.style !== '3d') {
                this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
            }
            
            // Get audio data
            const audioData = this.audioAnalyzer.analyzeAudio();
            
            // Choose visualization based on style
            switch (this.settings.style) {
                case 'waveform':
                    this.drawWaveform(audioData);
                    break;
                case 'bars':
                    this.drawBars(audioData);
                    break;
                case 'particles':
                    this.drawParticles(audioData);
                    break;
                case '3d':
                    this.draw3D(audioData);
                    break;
                default:
                    this.drawWaveform(audioData);
            }
            
            // Capture frame if recording
            if (this.recording) {
                this.recordingFrames.push(this.canvas.toDataURL('image/jpeg', 0.95));
            }
        };
        
        animate();
    }
    
    stopVisualization() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
            this.animationId = null;
        }
        
        // Cleanup 3D context if exists
        if (this.scene) {
            // Remove all 3D objects
            while(this.scene.children.length > 0) { 
                this.scene.remove(this.scene.children[0]); 
            }
            this.scene = null;
            this.camera = null;
            this.renderer = null;
            
            // Remove the 3D canvas if it exists
            const canvas3D = document.getElementById('3d-canvas');
            if (canvas3D) canvas3D.remove();
        }
    }
    
    drawWaveform(audioData) {
        const { timeData, beatDetection } = audioData;
        const width = this.canvas.width;
        const height = this.canvas.height;
        
        // Set line style
        this.ctx.lineWidth = 2;
        this.ctx.strokeStyle = beatDetection.isBeat ? this.settings.customization.color1 : this.settings.customization.color2;
        
        // Draw waveform
        this.ctx.beginPath();
        
        const sliceWidth = width / timeData.length;
        let x = 0;
        
        for (let i = 0; i < timeData.length; i++) {
            const v = timeData[i] / 128.0;
            const y = v * height / 2;
            
            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
            
            x += sliceWidth;
        }
        
        this.ctx.lineTo(width, height / 2);
        this.ctx.stroke();
        
        // Draw beat indicator
        if (beatDetection.isBeat) {
            const pulseSize = height * 0.4 * this.settings.customization.sensitivity;
            
            this.ctx.fillStyle = this.settings.customization.color1;
            this.ctx.globalAlpha = 0.2;
            this.ctx.beginPath();
            this.ctx.arc(width / 2, height / 2, pulseSize, 0, Math.PI * 2);
            this.ctx.fill();
            this.ctx.globalAlpha = 1.0;
        }
    }
    
    drawBars(audioData) {
        const { frequencyData, beatDetection } = audioData;
        const width = this.canvas.width;
        const height = this.canvas.height;
        
        // Number of bars based on complexity setting
        const maxBars = Math.min(frequencyData.length, 512);
        const barCount = Math.floor(maxBars * this.settings.customization.complexity);
        const barWidth = width / barCount;
        
        const sensitivity = this.settings.customization.sensitivity * 2.5;
        
        for (let i = 0; i < barCount; i++) {
            // Skip some bars for efficiency
            const index = Math.floor(i * (frequencyData.length / barCount));
            
            // Bar height based on frequency data
            const barHeight = (frequencyData[index] / 255) * height * sensitivity;
            
            // Determine color based on frequency
            const hue = (i / barCount) * 360;
            let color;
            
            if (beatDetection.isBeat && frequencyData[index] > 200) {
                color = this.settings.customization.color1;
            } else {
                color = `hsl(${hue}, 100%, 50%)`;
            }
            
            // Draw bar
            this.ctx.fillStyle = color;
            this.ctx.fillRect(i * barWidth, height - barHeight, barWidth, barHeight);
            
            // Draw mirror effect
            this.ctx.globalAlpha = 0.3;
            this.ctx.fillRect(i * barWidth, 0, barWidth, barHeight);
            this.ctx.globalAlpha = 1.0;
        }
    }
    
    drawParticles(audioData) {
        const { frequencyData, beatDetection, tempo } = audioData;
        const width = this.canvas.width;
        const height = this.canvas.height;
        
        // Create particle system if it doesn't exist
        if (!this.particles) {
            this.particles = [];
            const particleCount = Math.floor(200 * this.settings.customization.complexity);
            
            for (let i = 0; i < particleCount; i++) {
                this.particles.push({
                    x: Math.random() * width,
                    y: Math.random() * height,
                    size: Math.random() * 5 + 1,
                    speedX: (Math.random() - 0.5) * 2,
                    speedY: (Math.random() - 0.5) * 2,
                    color: `hsl(${Math.random() * 360}, 100%, 50%)`
                });
            }
        }
        
        // Draw background with fade effect
        this.ctx.fillStyle = this.settings.theme === 'dark' ? 'rgba(0, 0, 0, 0.2)' : 'rgba(255, 255, 255, 0.2)';
        this.ctx.fillRect(0, 0, width, height);
        
        // Get audio energy levels
        const bass = this.audioAnalyzer.getFrequencyBand('low');
        const mid = this.audioAnalyzer.getFrequencyBand('mid');
        const high = this.audioAnalyzer.getFrequencyBand('high');
        
        // Update and draw particles
        for (let i = 0; i < this.particles.length; i++) {
            const p = this.particles[i];
            
            // Update position based on audio
            const energyFactor = this.settings.customization.sensitivity;
            
            if (i % 3 === 0) {
                // Bass affects these particles
                p.x += p.speedX * (1 + bass * 5 * energyFactor);
                p.y += p.speedY * (1 + bass * 5 * energyFactor);
            } else if (i % 3 === 1) {
                // Mid frequencies affect these particles
                p.x += p.speedX * (1 + mid * 3 * energyFactor);
                p.y += p.speedY * (1 + mid * 3 * energyFactor);
            } else {
                // High frequencies affect these particles
                p.x += p.speedX * (1 + high * 2 * energyFactor);
                p.y += p.speedY * (1 + high * 2 * energyFactor);
            }
            
            // Bounce off walls
            if (p.x < 0 || p.x > width) p.speedX *= -1;
            if (p.y < 0 || p.y > height) p.speedY *= -1;
            
            // Size pulsates with beat
            let size = p.size;
            if (beatDetection.isBeat) {
                size *= 1.5;
            }
            
            // Draw particle
            this.ctx.fillStyle = p.color;
            this.ctx.beginPath();
            this.ctx.arc(p.x, p.y, size, 0, Math.PI * 2);
            this.ctx.fill();
            
            // Draw connections between particles
            if (this.settings.customization.complexity > 0.6) {
                for (let j = i + 1; j < this.particles.length; j++) {
                    const p2 = this.particles[j];
                    const dx = p.x - p2.x;
                    const dy = p.y - p2.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance < 100) {
                        this.ctx.beginPath();
                        this.ctx.strokeStyle = p.color;
                        this.ctx.globalAlpha = 1 - (distance / 100);
                        this.ctx.lineWidth = 1;
                        this.ctx.moveTo(p.x, p.y);
                        this.ctx.lineTo(p2.x, p2.y);
                        this.ctx.stroke();
                        this.ctx.globalAlpha = 1.0;
                    }
                }
            }
        }
        
        // Display BPM if available
        if (tempo.bpm > 0 && tempo.confidence > 0.5) {
            this.ctx.fillStyle = '#ffffff';
            this.ctx.font = '16px Arial';
            this.ctx.fillText(`BPM: ${tempo.bpm}`, 20, 30);
        }
    }
    
    init3D() {
        try {
            console.log("Initializing 3D scene...");
            
            // Check Three.js availability again
            if (typeof THREE === 'undefined') {
                console.error("Three.js is not loaded! Falling back to 2D visualization.");
                this.settings.style = 'waveform';
                return;
            }
            
            // Create a new canvas for 3D to avoid context conflicts
            const container = this.canvas.parentElement;
            
            // Clear previous 3D elements if any
            const oldCanvas3D = document.getElementById('3d-canvas');
            if (oldCanvas3D) oldCanvas3D.remove();
            
            // Create dedicated 3D canvas
            const canvas3D = document.createElement('canvas');
            canvas3D.id = '3d-canvas';
            canvas3D.width = this.canvas.width;
            canvas3D.height = this.canvas.height;
            canvas3D.style.position = 'absolute';
            canvas3D.style.top = '0';
            canvas3D.style.left = '0';
            canvas3D.style.width = '100%';
            canvas3D.style.height = '100%';
            container.appendChild(canvas3D);
            
            // Create Three.js scene
            this.scene = new THREE.Scene();
            this.camera = new THREE.PerspectiveCamera(75, canvas3D.width / canvas3D.height, 0.1, 1000);
            
            // Try creating renderer with error checking
            try {
                this.renderer = new THREE.WebGLRenderer({ 
                    canvas: canvas3D, 
                    alpha: true,
                    antialias: true 
                });
                this.renderer.setSize(canvas3D.width, canvas3D.height);
                console.log("3D renderer created successfully");
            } catch (e) {
                console.error("Failed to create WebGL renderer:", e);
                this.settings.style = 'waveform';
                return;
            }
            
            // Set camera position
            this.camera.position.z = 5;
            
            // Add ambient light
            const ambientLight = new THREE.AmbientLight(0x404040);
            this.scene.add(ambientLight);
            
            // Add directional light
            const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
            directionalLight.position.set(1, 1, 1);
            this.scene.add(directionalLight);
            
            // Add objects based on complexity
            this.create3DObjects();
            
            console.log("3D initialization complete");
        } catch (error) {
            console.error("Error in 3D initialization:", error);
            this.settings.style = 'waveform';
        }
    }
    
    create3DObjects() {
        // Clear existing objects
        while(this.scene.children.length > 0) { 
            const obj = this.scene.children[0];
            if (obj.type === 'Light') {
                this.scene.remove(obj);
            }
        }
        
        const complexity = this.settings.customization.complexity;
        
        // Create central object
        const geometry = new THREE.IcosahedronGeometry(1, Math.floor(complexity * 3));
        const material = new THREE.MeshPhongMaterial({
            color: new THREE.Color(this.settings.customization.color1),
            wireframe: complexity < 0.5,
            emissive: new THREE.Color(this.settings.customization.color2),
            emissiveIntensity: 0.5,
            specular: new THREE.Color(0xffffff)
        });
        
        this.centralObject = new THREE.Mesh(geometry, material);
        this.scene.add(this.centralObject);
        
        // Create frequency bars
        this.frequencyBars = [];
        const barCount = Math.floor(64 * complexity);
        
        for (let i = 0; i < barCount; i++) {
            const barGeometry = new THREE.BoxGeometry(0.05, 0.05, 1);
            const barMaterial = new THREE.MeshPhongMaterial({
                color: new THREE.Color(`hsl(${(i / barCount) * 360}, 100%, 50%)`),
                emissive: new THREE.Color(`hsl(${(i / barCount) * 360}, 100%, 70%)`),
                emissiveIntensity: 0.5
            });
            
            const bar = new THREE.Mesh(barGeometry, barMaterial);
            
            // Position in a circle
            const angle = (i / barCount) * Math.PI * 2;
            const radius = 2.5;
            bar.position.x = Math.cos(angle) * radius;
            bar.position.y = Math.sin(angle) * radius;
            bar.position.z = 0;
            
            // Rotate to point outward
            bar.rotation.z = angle + Math.PI / 2;
            
            this.scene.add(bar);
            this.frequencyBars.push(bar);
        }
        
        // Add particles if complexity is high
        if (complexity > 0.7) {
            this.particleSystem = new THREE.Group();
            const particleCount = Math.floor(500 * complexity);
            
            for (let i = 0; i < particleCount; i++) {
                const particleGeometry = new THREE.SphereGeometry(0.02, 4, 4);
                const particleMaterial = new THREE.MeshBasicMaterial({
                    color: new THREE.Color(`hsl(${(i / particleCount) * 360}, 100%, 70%)`)
                });
                
                const particle = new THREE.Mesh(particleGeometry, particleMaterial);
                
                // Random position in a sphere
                const radius = 4 + Math.random() * 2;
                const theta = Math.random() * Math.PI * 2;
                const phi = Math.acos(2 * Math.random() - 1);
                
                particle.position.x = radius * Math.sin(phi) * Math.cos(theta);
                particle.position.y = radius * Math.sin(phi) * Math.sin(theta);
                particle.position.z = radius * Math.cos(phi);
                
                // Store original position
                particle.userData = {
                    originalPos: particle.position.clone(),
                    phase: Math.random() * Math.PI * 2
                };
                
                this.particleSystem.add(particle);
            }
            
            this.scene.add(this.particleSystem);
        }
    }
    
    draw3D(audioData) {
        try {
            if (!this.scene || !this.camera || !this.renderer) {
                // If 3D is not properly initialized, try to initialize it
                if (this.settings.style === '3d' && !this.scene) {
                    this.init3D();
                    
                    // If still not initialized, fallback to 2D
                    if (!this.scene || !this.camera || !this.renderer) {
                        console.warn("3D rendering still unavailable, falling back to waveform");
                        this.settings.style = 'waveform';
                        return;
                    }
                } else {
                    return;
                }
            }
            
            const { frequencyData, beatDetection } = audioData;
            
            // Get band levels
            const bass = this.audioAnalyzer.getFrequencyBand('low');
            const mid = this.audioAnalyzer.getFrequencyBand('mid');
            const high = this.audioAnalyzer.getFrequencyBand('high');
            
            const sensitivity = this.settings.customization.sensitivity;
            
            // Animate central object
            if (this.centralObject) {
                this.centralObject.rotation.x += 0.005 + bass * 0.05 * sensitivity;
                this.centralObject.rotation.y += 0.01 + mid * 0.05 * sensitivity;
                
                // Scale with beat
                const scale = 1 + bass * sensitivity;
                this.centralObject.scale.set(scale, scale, scale);
                
                // Change color on beat
                if (beatDetection.isBeat) {
                    this.centralObject.material.emissiveIntensity = 1.0;
                } else {
                    this.centralObject.material.emissiveIntensity = 0.5;
                }
            }
            
            // Animate frequency bars
            if (this.frequencyBars && this.frequencyBars.length > 0) {
                for (let i = 0; i < this.frequencyBars.length; i++) {
                    const index = Math.floor(i * (frequencyData.length / this.frequencyBars.length));
                    const value = frequencyData[index] / 255;
                    
                    const scale = 0.1 + value * 2 * sensitivity;
                    this.frequencyBars[i].scale.z = scale;
                    
                    // Rotate based on frequency value
                    this.frequencyBars[i].rotation.x += value * 0.01;
                }
            }
            
            // Animate particles
            if (this.particleSystem && this.particleSystem.children) {
                const time = performance.now() * 0.001;
                
                for (let i = 0; i < this.particleSystem.children.length; i++) {
                    const particle = this.particleSystem.children[i];
                    
                    // Skip if particle doesn't have userData
                    if (!particle.userData || !particle.userData.originalPos) continue;
                    
                    const originalPos = particle.userData.originalPos;
                    const phase = particle.userData.phase;
                    
                    // Choose which frequency band affects this particle
                    let frequencyInfluence;
                    if (i % 3 === 0) {
                        frequencyInfluence = bass;
                    } else if (i % 3 === 1) {
                        frequencyInfluence = mid;
                    } else {
                        frequencyInfluence = high;
                    }
                    
                    // Calculate new position with wave motion and frequency influence
                    particle.position.x = originalPos.x + Math.sin(time + phase) * frequencyInfluence * sensitivity;
                    particle.position.y = originalPos.y + Math.cos(time + phase) * frequencyInfluence * sensitivity;
                    particle.position.z = originalPos.z + Math.sin(time * 0.5 + phase) * frequencyInfluence * sensitivity;
                    
                    // Scale with beat
                    if (beatDetection.isBeat && frequencyInfluence > 0.5) {
                        particle.scale.set(3, 3, 3);
                    } else {
                        particle.scale.set(1, 1, 1);
                    }
                }
                
                // Rotate particle system
                this.particleSystem.rotation.y += 0.001;
            }
            
            // Move camera slightly based on beats
            if (beatDetection.isBeat) {
                this.camera.position.z = 5 - bass * sensitivity;
            } else {
                this.camera.position.z += (5 - this.camera.position.z) * 0.1;
            }
            
            // Render scene
            this.renderer.render(this.scene, this.camera);
        } catch (error) {
            console.error("Error in 3D rendering:", error);
            // Fallback to 2D visualization on error
            this.settings.style = 'waveform';
        }
    }
    
    setStyle(style) {
        this.settings.style = style;
        
        // Cleanup previous state
        this.particles = null;
        
        // Remove any existing 3D canvas when switching away from 3D
        if (style !== '3d') {
            const canvas3D = document.getElementById('3d-canvas');
            if (canvas3D) canvas3D.remove();
        }
        
        // Initialize 3D if needed
        if (style === '3d' && !this.scene) {
            console.log("Switching to 3D visualization");
            this.init3D();
            
            // If 3D initialization fails, fall back to waveform
            if (!this.scene || !this.camera || !this.renderer) {
                console.warn("Failed to initialize 3D, falling back to waveform");
                this.settings.style = 'waveform';
                
                // Notify user
                alert("3D visualization is not supported in your browser. Falling back to waveform visualization.");
            }
        }
    }
    
    setTheme(theme) {
        this.settings.theme = theme;
    }
    
    setCustomization(options) {
        this.settings.customization = { ...this.settings.customization, ...options };
        
        // Update 3D objects if needed
        if (this.settings.style === '3d' && this.scene) {
            this.create3DObjects();
        }
    }
    
    startRecording(options = {}) {
        this.recording = true;
        this.recordingFrames = [];
        
        const resolution = options.resolution || '1080p';
        const format = options.format || 'mp4';
        
        // Set recording resolution
        const originalWidth = this.canvas.width;
        const originalHeight = this.canvas.height;
        
        let recordingWidth, recordingHeight;
        
        switch (resolution) {
            case '720p':
                recordingWidth = 1280;
                recordingHeight = 720;
                break;
            case '1080p':
                recordingWidth = 1920;
                recordingHeight = 1080;
                break;
            case '4k':
                recordingWidth = 3840;
                recordingHeight = 2160;
                break;
            default:
                recordingWidth = originalWidth;
                recordingHeight = originalHeight;
        }
        
        // Store original size to restore later
        this.originalSize = { width: originalWidth, height: originalHeight };
        
        // Set canvas to recording size
        this.canvas.width = recordingWidth;
        this.canvas.height = recordingHeight;
        
        // If 3D context is active
        if (this.renderer) {
            this.renderer.setSize(recordingWidth, recordingHeight);
            this.camera.aspect = recordingWidth / recordingHeight;
            this.camera.updateProjectionMatrix();
        }
        
        return {
            width: recordingWidth,
            height: recordingHeight,
            format: format
        };
    }
    
    stopRecording() {
        this.recording = false;
        
        // Restore original canvas size
        if (this.originalSize) {
            this.canvas.width = this.originalSize.width;
            this.canvas.height = this.originalSize.height;
            
            // If 3D context is active
            if (this.renderer) {
                this.renderer.setSize(this.originalSize.width, this.originalSize.height);
                this.camera.aspect = this.originalSize.width / this.originalSize.height;
                this.camera.updateProjectionMatrix();
            }
            
            this.originalSize = null;
        }
        
        return this.recordingFrames;
    }
    
    exportVideo(frames, fps = 30, format = 'mp4') {
        return new Promise((resolve, reject) => {
            if (frames.length === 0) {
                reject(new Error('No frames to export'));
                return;
            }
            
            // Create a temporary canvas for the video
            const tempCanvas = document.createElement('canvas');
            
            // Get first frame to determine dimensions
            const img = new Image();
            img.onload = () => {
                tempCanvas.width = img.width;
                tempCanvas.height = img.height;
                const ctx = tempCanvas.getContext('2d');
                
                // Set MIME type based on format
                const mimeType = format === 'webm' ? 'video/webm' : 'video/mp4';
                
                // Set up media recorder
                try {
                    const stream = tempCanvas.captureStream(fps);
                    this.mediaRecorder = new MediaRecorder(stream, {
                        mimeType: MediaRecorder.isTypeSupported(mimeType) ? mimeType : 'video/webm',
                        videoBitsPerSecond: 8000000 // 8 Mbps
                    });
                    
                    this.chunks = [];
                    this.mediaRecorder.ondataavailable = (e) => {
                        if (e.data.size > 0) {
                            this.chunks.push(e.data);
                        }
                    };
                    
                    this.mediaRecorder.onstop = () => {
                        const blob = new Blob(this.chunks, { type: mimeType });
                        const url = URL.createObjectURL(blob);
                        resolve(url);
                    };
                    
                    // Start recording
                    this.mediaRecorder.start();
                    
                    // Process frames
                    let frameIndex = 0;
                    
                    const processFrame = () => {
                        if (frameIndex < frames.length) {
                            const frameImg = new Image();
                            frameImg.onload = () => {
                                ctx.drawImage(frameImg, 0, 0);
                                frameIndex++;
                                
                                // Schedule next frame
                                setTimeout(processFrame, 1000 / fps);
                            };
                            frameImg.src = frames[frameIndex];
                        } else {
                            // End recording
                            this.mediaRecorder.stop();
                        }
                    };
                    
                    // Start processing frames
                    processFrame();
                    
                } catch (error) {
                    reject(error);
                }
            };
            
            img.src = frames[0];
        });
    }
}

// main.js
// Function to dynamically load scripts
function loadScript(url) {
    return new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = url;
        script.onload = () => resolve();
        script.onerror = () => reject(new Error(`Failed to load script: ${url}`));
        document.head.appendChild(script);
    });
}

// Load required libraries first
async function loadLibraries() {
    try {
        // Try multiple CDNs for Three.js
        try {
            await loadScript('https://cdnjs.cloudflare.com/ajax/libs/three.js/r148/three.min.js');
        } catch (e) {
            console.warn("Failed to load Three.js from cdnjs, trying unpkg...");
            await loadScript('https://unpkg.com/three@0.148.0/build/three.min.js');
        }
        
        // Load dat.GUI
        await loadScript('https://cdnjs.cloudflare.com/ajax/libs/dat-gui/0.7.9/dat.gui.min.js');
        
        console.log("All libraries loaded successfully!");
        return true;
    } catch (error) {
        console.error("Error loading libraries:", error);
        return false;
    }
}